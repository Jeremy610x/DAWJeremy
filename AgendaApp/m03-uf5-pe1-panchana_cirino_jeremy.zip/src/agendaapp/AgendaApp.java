/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package agendaapp;

import agendaapp.Contacte;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jepa2698
 */
public class AgendaApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      
        AgendaApp a = new AgendaApp();
        a.run();
        }
        private void run() {
        //Opció B: TODO declarar i instanciar variables per emmagatzemar els contactes
        
        carregarContactes(/*estructura que conte dades*/);
        llistarAgenda(/*estructura que conte dades*/);
        //TODO tenir en compte l'excepció
        llistarPerEdat(/*estructura que conte dades*/);
        passarAny/*estructura que conte dades*/();
        llistarAgenda(/*estructura que conte dades*/);
        canviarNom(/*estructura que conte dades*/);
        llistarAgenda(/*estructura que conte dades*/);
        } 
        //TODO definir els mètodes requerits ( NO han de ser 'static')       
        //Opció A: els mètodes no reben cap paràmetre
        //Opció B: cal que definiu els paràmetres que han de rebre

    private void carregarContactes( ) {


        
        
     
        
        
      
    }

    private void llistarAgenda() {
        
    }

    private void llistarPerEdat() {
        
    }

    private void passarAny() {
      
    }

    private void canviarNom() {
       
    }


        
        
      }
                

