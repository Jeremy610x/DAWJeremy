/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package patrullacanina.Objects;

/**
 *
 * @author jepa2698
 */
public interface ApagarFocs {
    public void apagarFoc();
}
