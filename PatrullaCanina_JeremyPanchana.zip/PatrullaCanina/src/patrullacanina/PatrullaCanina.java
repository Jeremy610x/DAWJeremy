/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patrullacanina;
import patrullacanina.Objects.Gos;
import patrullacanina.Objects.Policia;
import patrullacanina.Objects.Nedador;
import patrullacanina.Objects.Bomber;

/**
 *
 * @author jepa2698
 */
public class PatrullaCanina {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
          
        Gos[] gossos = new Gos [6];
        
        
        creaPersonatges();
        
        
        
        
    }

    private static void creaPersonatges() {
       Policia [0] = new Policia ("Policia_1");
       Policia [1] = new Policia ("Policia_2");
       Nedador [2] = new Nedador ("Nedador_1");
       Nedador [3] = new Nedador ("Nedador_2");
       Bomber [4] = new Bomber("Nedador_1");
       Bomber  [5] = new Bomber ("Nedador_2");
       
       
       
       
       
       
       
    }
    
    
}
