package cat.proven.pokedex.model;

/**
 *
 * @author ProvenSoft
 */
public enum Genre {
    MALE, FEMALE, BOTH
}
