package cat.proven.pokedex.model;

import java.util.Objects;

/**
 *
 * @author ProvenSoft
 */
public class Pokemon {

    private long id;
    private String name;
    private double height;
    private double weight;
    private Genre genre;
    private PokemonType tipo;
    /* faltaria si lo implementais atributo para la evolution;*/

    public Pokemon(long id, String name, double height, double weight, Genre genre, PokemonType type) {
        this.id = id;
        this.name = name;
        this.height = height;
        this.weight = weight;
        this.genre = genre;
        this.tipo = type;
    }

  /*podeis añadir constructores que necesiteis*/
    /*getters y seeter necesario*/
    /*toString tambien*/
    /*pokemon es igual a otro por su nombre*/

}
