package cat.proven.pokedex.model;

import cat.proven.pokedex.model.persist.DbConnect;

/**
 *
 * @author ProvenSoft
 */
public class PokemonModel {

    private final DbConnect dbConnect=null;
    public PokemonModel() throws ClassNotFoundException {
/*        DbConnect.loadDriver();
        dbConnect = new DbConnect();*/
    }
    
    //TODO
    
    
        
}
