package cat.proven.pokedex.model.persist;

/**
 *
 * @author ProvenSoft
 */
public class PokemonDao {

    private final DbConnect dbConnect;

    public PokemonDao(DbConnect connect) {
        this.dbConnect = connect;
    }
    
    //TODO
    
}
