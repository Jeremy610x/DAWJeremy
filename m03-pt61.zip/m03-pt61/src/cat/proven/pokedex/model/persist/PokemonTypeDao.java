package cat.proven.pokedex.model.persist;

/**
 *
 * @author ProvenSoft
 */
public class PokemonTypeDao {

    private final DbConnect dbConnect;

    public PokemonTypeDao(DbConnect connect) {
        this.dbConnect = connect;
    }
    
    //TODO
    
}
